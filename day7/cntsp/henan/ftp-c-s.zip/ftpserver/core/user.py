#!-*- coding:utf8 -*-

import json
import os
import sys

db_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class User(object):
    def __init__(self, username="", password="", flag=False):
        self.username = username
        self.password = password
        self.flag = flag

    def login(self):
        while True:
            username = input("please enter your username:").strip()
            password = input("please enter your password:").strip()
            self.username = username
            self.password = password
            data = self.read_user_information()
            if self.username in data.keys() and self.password == data[username][username]:
                print("\033[32;1m welcome login ftp server! \033[0m")
                flag = False
                return True
            else:
                print("\033[31;1m your usernmae or password is false\033[0m")
                flag = True
                return False

    def write_user_information(self):
        """
        create user login information, and write it to db.
        :return:
        """
        self.flag = True
        with open(db_path + '/data/' + "user.json", "r") as f:
           data = json.load(f)
        data[self.username] = {"username": self.username, "password": self.password}
        with open(db_path + '/data/' + "user.json", "w") as f:
            json.dump(data, f)

    def read_user_information(self):
        """
        read user login information, and return it
        :return:
        """
        with open(db_path + '/data/' + "user.json", "r") as f:
            data = json.load(f)
        # print("root:", data['root'])
        return data

    def create_user_home_directory(self):
        """
        create user home directory
        :return: user's home directory
        """

        home_directory = "/home/" + self.username
        os.system("mkdir %s" % self.username)
        return home_directory


if __name__ == "__main__":
    # r1 运行生产默认的root用户
    # r1 = User()
    # r1.write_user()
    # r1.read_user()
      
    r2 = User("xiaojie","nihaoma")
    # r2.write_user_information()
    # r2.read_user_information() 
