import socket
import os
import json
import hashlib
from authentication import User
import commands

# import re

class FtpClient(object):
    """
    define the ftpclient class
    """

    def __init__(self, host="localhost", port=9999):
        self.client = socket.socket()
        self.host = host
        self.port = port
        self.client_user = User()
        self.connection(self.host, self.port)
        self.commands = commands.cmd(self.client)

    def connection(self, *args):
        print(args[0], args[1])
        # self.client = socket.socket()
        c1 = self.client.connect((args[0], args[1]))
        print("line25: ", c1)
        if not c1:
            username = self.client_user.login(self.client)
            if username:
                self.commands.help()
                self.handle(username)
                self.client.close()
        else:
            print("the client failed to connect to the server")

    def handle(self, username):
        """
        analyze the data entered, in order to get command and filename.
        :return:
        """
        # command1 = commands.cmd(self.client)
        flag = True
        while flag:
            enter_data = input("ftp>[/home/%s]" % username).strip()
            enter_data_tuple = enter_data.split()
            if enter_data_tuple[0].startswith('put') or enter_data_tuple[0].startswith('get'):
                command = enter_data_tuple[0]
                filename = enter_data_tuple[1]
                if hasattr(self.commands, "cmd_{}".format(command)):
                    if os.path.isfile(filename):
                        # print("ftpclient line 38:")
                        try:
                            size = os.stat(filename).st_size
                        except FileNotFoundError as e:
                            size = 0
                        msg_dict = {
                            "username": username,
                            "action": command,
                            "filename": filename,
                            "file_size": size,
                            "override": True,
                        }
                        func = getattr(self.commands, "cmd_{}".format(command))
                        print("line 48", func)
                        func(msg_dict)
                    else:
                        print("your operate {} file is not exist!".format(filename))
            elif enter_data_tuple[0].startswith('ls') or enter_data_tuple[0].startswith('cd') or enter_data_tuple[0].startswith('mkdir'):
                try:
                    command = enter_data_tuple[0]
                    second_parameter = enter_data_tuple[1]
                    # print("line 71:",command, second_parameter)
                    msg_dict = {
                        "action": command,
                        "second_parameter": second_parameter,
                        "username": username,
                        "home_directory": "/home/%s" % username
                    }
                    # print("@@@ line 57:")
                except IndexError as e:
                    print("your enter commands has a false:", e)
                if hasattr(self.commands, "cmd_{}".format(enter_data_tuple[0])):
                    func = getattr(self.commands, "cmd_{}".format(enter_data_tuple[0]))
                    self.commands.func(msg_dict)
            elif enter_data_tuple[0].startswith('exit'):
                flag = False
            else:
                print("the data of your enter has error! please Usage: ")
                self.commands.help()


f1 = FtpClient()
